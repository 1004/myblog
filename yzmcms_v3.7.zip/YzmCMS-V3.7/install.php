<?php
header("location: application/install/");