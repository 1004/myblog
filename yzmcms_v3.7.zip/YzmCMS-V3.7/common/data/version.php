<?php 
//软件摘要信息，****请不要修改或删除本项**** 否则系统无法正确接收系统漏洞或升级信息
define('YZMCMS_VERSION', 'V3.7'); 
define('YZMCMS_UPDATE', '20180306');