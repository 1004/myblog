<?php
/**
 * @explain  		 YZMCMS 简体中文语言包
 * @author           袁志蒙  
 * @license          http://www.yzmcms.com
 */
return array( 
	'link' => '友情链接',
	'add_link' => '添加友情链接',
	'edit_link' => '编辑友情链接',
	'del_link' => '删除友情链接',
);