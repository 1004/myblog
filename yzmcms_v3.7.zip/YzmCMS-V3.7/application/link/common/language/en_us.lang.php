<?php
/**
 * @explain  		 YZMCMS English language package
 * @author           袁志蒙  
 * @license          http://www.yzmcms.com
 */
return array( 
	'link' => 'Friendship link',
	'add_link' => 'Add link',
	'edit_link' => 'Edit link',
	'del_link' => 'Delete link',
);