<?php defined('IN_YZMCMS') or exit('No Define YzmCMS.'); ?>
<div class="footer"> &copy; 2014-2018 <a href="http://www.yzmcms.com/" target="_blank">www.yzmcms.com</a> YzmCMS内容管理系统 </div>