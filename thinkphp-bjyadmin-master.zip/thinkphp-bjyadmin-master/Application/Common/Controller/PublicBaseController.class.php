<?php
namespace Common\Controller;
use Common\Controller\BaseController;
/**
 * 通用基类控制器
 */
class PublicBaseController extends BaseController{
	/**
	 * 初始化方法
	 */
	public function _initialize(){
		parent::_initialize();

	}




}

