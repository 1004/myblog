<?php
namespace Common\Model;
use Think\Model;
/**
* 基类model
*/
Class BaseModel extends Model{


}
