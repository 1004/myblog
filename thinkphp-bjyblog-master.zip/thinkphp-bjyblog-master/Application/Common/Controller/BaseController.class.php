<?php
namespace Common\Controller;
use Think\Controller;
/**
 * 基类Controller
 */
class BaseController extends Controller{
    /**
     * 初始化方法
     */
    public function _initialize(){
        
    }



}

